package com.payflow.payflow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PayflowApplicationTests {

	@Test
	void contextLoads() {
	}

}
